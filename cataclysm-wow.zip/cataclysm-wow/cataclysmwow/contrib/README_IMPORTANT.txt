=====New Install=====
Make sure that your prosilver style is up to date. It has to be at least phpBB Version 3.0.10.
Otherwise you might run into problems.
You do not have to enable prosilver BUT the prosilver files have to stay in the styles directory.

=====Upgrade from earlier versions=====
First make sure you have phpBB 3.0.10 or above installed. The prosilver style has to be up to date
and reside in the styles directory.
Now delete the old cataclysmwow folder. Upload the contents of this zip. Refresh your forum cache and
then your browser cache.



===Why?===
The style has been converted into a child style which means it uses most template files from the default
prosilver style. That makes it a lot easier to update for me when phpBB releases an upgrade.